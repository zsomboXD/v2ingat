import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { getData } from '../utils';
import { useNavigate } from 'react-router-dom';

const categ_url = "http://localhost:8000/api/categories"


export const Home = () => {
  const navigate = useNavigate()
  const { data } = useQuery({ queryKey: ['categories', categ_url], queryFn: getData })

  data && console.log(data);

  return (
    <div>
      <div className='header'>
        <p className='home'>🏠</p>
        <h2>Találd meg álmaid otthonát!</h2>
      </div>

      {data && data.map(obj =>
        <div className="cards">
          {obj.nev}
        </div>
      )}
      <div className='footer'>
        <p className='foot'>Kapcsolat: ingatlanok@gmail.cum</p>
      </div>
    </div>
  )
}
import React from 'react'

export const Home = () => {
  return (
    <div>
      <header>Találd meg álmaid otthonát!</header>
        <p>Böngéssz a legjobb ajánlatok között, legyen szó lakásról, házról vagy üzleti ingatlanról.</p>
        <p>Válogass kategóriáink közül és lépj a következő otthonod felé!</p>
      <footer>
           <p>Kapcsolat: <span>ingatlanok@gmail.com</span></p> 
    </footer>
    </div>
  )
}


